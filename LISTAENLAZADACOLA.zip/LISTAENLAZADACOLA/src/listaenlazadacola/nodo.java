/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaenlazadacola;

import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class nodo {
    
   int dato;
    nodo siguiente;

    public nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }

  

}