/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaenlazadacola;

import java.util.Scanner;
/**
 *
 * @author usuario
 */
public class LISTAENLAZADACOLA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado = new Scanner(System.in);

        Cola cola = null;

        int opcion;

        do {

            System.out.println("\n========================");
            System.out.println("       MENU COLA");
            System.out.println("========================");
            System.out.println("1. Construir / inicializar cola");
            System.out.println("2. Insertar elemento");
            System.out.println("3. Retirar elemento");
            System.out.println("4. Consultar cola");
            System.out.println("5. Mostrar longitud");
            System.out.println("6. Verificar si está vacía");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();

            switch (opcion) {

                case 1:

                    cola = new Cola();

                    System.out.println("Cola construida correctamente.");

                    break;

                case 2:

                    if (cola == null) {

                        System.out.println("Primero debe construir la cola.");

                    } else {

                        System.out.print("Ingrese el dato: ");

                        int dato = teclado.nextInt();

                        cola.insertar(dato);
                    }

                    break;

                case 3:

                    if (cola == null) {

                        System.out.println("Primero debe construir la cola.");

                    } else {

                        cola.retirar();
                    }

                    break;

                case 4:

                    if (cola == null) {

                        System.out.println("Primero debe construir la cola.");

                    } else {

                        cola.mostrar();
                    }

                    break;

                case 5:

                    if (cola == null) {

                        System.out.println("Primero debe construir la cola.");

                    } else {

                        System.out.println("Longitud de la cola: "
                                + cola.longitud());
                    }

                    break;

                case 6:

                    if (cola == null) {

                        System.out.println("Primero debe construir la cola.");

                    } else {

                        if (cola.estaVacia()) {

                            System.out.println("La cola está vacía.");

                        } else {

                            System.out.println("La cola NO está vacía.");
                        }
                    }

                    break;

                case 7:

                    System.out.println("Programa finalizado.");

                    break;

                default:

                    System.out.println("Opción inválida.");
            }

        } while (opcion != 7);

        teclado.close();
    }
}
