/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listaenlazadacola;

/**
 *
 * @author usuario
 */
public class Cola {
    
    
    private nodo frente;
    private nodo fin;
    private int tamaño;

    // 1. Construir o inicializar la cola
    public Cola() {
        frente = null;
        fin = null;
        tamaño = 0;
    }

    // 2. Insertar un elemento en la cola
    public void insertar(int dato) {

        nodo nuevo = new nodo(dato);

        // Si la cola está vacía
        if (frente == null) {

            frente = nuevo;
            fin = nuevo;

        } else {

            fin.siguiente = nuevo;
            fin = nuevo;
        }

        tamaño++;

        System.out.println("Elemento insertado correctamente.");
    }

    // 3. Retirar un elemento por el frente
    public void retirar() {

        if (frente == null) {
            System.out.println("La cola está vacía.");
            return;
        }

        int datoRetirado = frente.dato;

        frente = frente.siguiente;

        // Si después de retirar la cola queda vacía
        if (frente == null) {
            fin = null;
        }

        tamaño--;

        System.out.println("Elemento retirado: " + datoRetirado);
    }

    // 4. Consultar la cola
    public void mostrar() {

        if (frente == null) {
            System.out.println("La cola está vacía.");
            return;
        }

        nodo actual = frente;

        System.out.println("\nElementos de la cola:");

        while (actual != null) {

            System.out.print(actual.dato + " =>");

            actual = actual.siguiente;
        }

        System.out.println();
    }

    // 5. Determinar el número de elementos
    public int longitud() {
        return tamaño;
    }

    // 6. Determinar si la cola está vacía
    public boolean estaVacia() {
        return frente == null;
    }
    
}
